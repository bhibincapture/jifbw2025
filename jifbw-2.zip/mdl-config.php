<?php
//
// Database
//
define("DB_HOST", "localhost");
define("DB_NAME", "jifbw");
define("DB_USER", "root");
define("DB_PASS", "");
/*
define("DB_HOST", "localhost");
define("DB_NAME", "jeps9918_jifbw2024");
define("DB_USER", "jeps9918_jifbw2024");
define("DB_PASS", "{eZ4RVkGyRr4");
*/
?>